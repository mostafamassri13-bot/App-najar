package com.example.ui

import kotlin.math.max
import kotlin.math.min

data class CutItem(
    val id: String,
    val name: String,
    val width: Double,
    val height: Double,
    val quantity: Int,
    val colorHex: String = "#FF9800" // Custom visual color
)

data class PlacedItem(
    val id: String,
    val name: String,
    val x: Double,
    val y: Double,
    val width: Double,
    val height: Double,
    val isRotated: Boolean,
    val colorHex: String
)

data class FreeRect(
    val x: Double,
    val y: Double,
    val width: Double,
    val height: Double
)

data class SheetResult(
    val sheetIndex: Int,
    val placedItems: List<PlacedItem>,
    val freeSpaces: List<FreeRect>,
    val totalArea: Double,
    val usedArea: Double,
    val wasteArea: Double,
    val efficiencyPercentage: Double
)

data class OptimizerResult(
    val sheets: List<SheetResult>,
    val unplacedItems: List<CutItem>,
    val totalSheetsUsed: Int,
    val overallEfficiency: Double
)

object CuttingListOptimizer {

    fun optimize(
        sheetWidth: Double,
        sheetHeight: Double,
        items: List<CutItem>,
        kerf: Double = 0.3, // blade thickness, default 3mm
        allowRotation: Boolean = true
    ): OptimizerResult {
        if (sheetWidth <= 0 || sheetHeight <= 0 || items.isEmpty()) {
            return OptimizerResult(emptyList(), emptyList(), 0, 0.0)
        }

        // Expand the quantities into individual items to place
        val flatItems = mutableListOf<CutItem>()
        items.forEach { item ->
            repeat(item.quantity) { index ->
                flatItems.add(item.copy(id = "${item.id}_$index"))
            }
        }

        // Sort items by area in descending order (standard best-fit heuristic)
        // We can also sort by max dimension to prioritize longer pieces first
        flatItems.sortWith(compareByDescending<CutItem> { max(it.width, it.height) }.thenByDescending { it.width * it.height })

        val sheets = mutableListOf<SheetResult>()
        val unplaced = mutableListOf<CutItem>()

        // Helper function to create a new sheet state
        fun createNewSheet(index: Int) = SheetResult(
            sheetIndex = index,
            placedItems = emptyList(),
            freeSpaces = listOf(FreeRect(0.0, 0.0, sheetWidth, sheetHeight)),
            totalArea = sheetWidth * sheetHeight,
            usedArea = 0.0,
            wasteArea = sheetWidth * sheetHeight,
            efficiencyPercentage = 0.0
        )

        var currentSheetIndex = 1
        var currentSheet = createNewSheet(currentSheetIndex)

        for (item in flatItems) {
            val itemW = item.width
            val itemH = item.height

            // Check if item exceeds the raw sheet dimension in both orientations
            val fitsNormal = itemW <= sheetWidth && itemH <= sheetHeight
            val fitsRotated = allowRotation && itemH <= sheetWidth && itemW <= sheetHeight

            if (!fitsNormal && !fitsRotated) {
                // This single item is physically larger than any sheet
                // Group it back to unplaced
                unplaced.add(item)
                continue
            }

            var placed = false

            // Try to place the item in existing sheets first
            for (sIndex in 0 until sheets.size) {
                val s = sheets[sIndex]
                val placement = findBestPlacement(s.freeSpaces, itemW, itemH, allowRotation)
                if (placement != null) {
                    val (rect, rotate) = placement
                    val finalW = if (rotate) itemH else itemW
                    val finalH = if (rotate) itemW else itemH

                    val placedItem = PlacedItem(
                        id = item.id,
                        name = item.name,
                        x = rect.x,
                        y = rect.y,
                        width = finalW,
                        height = finalH,
                        isRotated = rotate,
                        colorHex = item.colorHex
                    )

                    val updatedPlaced = s.placedItems + placedItem
                    val updatedFree = splitFreeRect(s.freeSpaces, rect, finalW, finalH, kerf)

                    val usedArea = updatedPlaced.sumOf { it.width * it.height }
                    val totalArea = s.totalArea
                    val wasteArea = totalArea - usedArea
                    val efficiency = (usedArea / totalArea) * 100.0

                    sheets[sIndex] = s.copy(
                        placedItems = updatedPlaced,
                        freeSpaces = updatedFree,
                        usedArea = usedArea,
                        wasteArea = wasteArea,
                        efficiencyPercentage = efficiency
                    )
                    placed = true
                    break
                }
            }

            if (!placed) {
                // Try current sheet
                val placement = findBestPlacement(currentSheet.freeSpaces, itemW, itemH, allowRotation)
                if (placement != null) {
                    val (rect, rotate) = placement
                    val finalW = if (rotate) itemH else itemW
                    val finalH = if (rotate) itemW else itemH

                    val placedItem = PlacedItem(
                        id = item.id,
                        name = item.name,
                        x = rect.x,
                        y = rect.y,
                        width = finalW,
                        height = finalH,
                        isRotated = rotate,
                        colorHex = item.colorHex
                    )

                    val updatedPlaced = currentSheet.placedItems + placedItem
                    val updatedFree = splitFreeRect(currentSheet.freeSpaces, rect, finalW, finalH, kerf)

                    val usedArea = updatedPlaced.sumOf { it.width * it.height }
                    val totalArea = currentSheet.totalArea
                    val wasteArea = totalArea - usedArea
                    val efficiency = (usedArea / totalArea) * 100.0

                    currentSheet = currentSheet.copy(
                        placedItems = updatedPlaced,
                        freeSpaces = updatedFree,
                        usedArea = usedArea,
                        wasteArea = wasteArea,
                        efficiencyPercentage = efficiency
                    )
                } else {
                    // Current sheet is full for this item, push current sheet to sheets list
                    if (currentSheet.placedItems.isNotEmpty()) {
                        sheets.add(currentSheet)
                    } else {
                        // Current sheet was empty but couldn't place item? Should not happen since we checked sheet limits,
                        // but handle just in case to avoid infinite loop.
                        unplaced.add(item)
                        continue
                    }

                    // Open a new sheet
                    currentSheetIndex++
                    currentSheet = createNewSheet(currentSheetIndex)

                    // Place in new sheet
                    val newPlacement = findBestPlacement(currentSheet.freeSpaces, itemW, itemH, allowRotation)
                    if (newPlacement != null) {
                        val (rect, rotate) = newPlacement
                        val finalW = if (rotate) itemH else itemW
                        val finalH = if (rotate) itemW else itemH

                        val placedItem = PlacedItem(
                            id = item.id,
                            name = item.name,
                            x = rect.x,
                            y = rect.y,
                            width = finalW,
                            height = finalH,
                            isRotated = rotate,
                            colorHex = item.colorHex
                        )

                        val updatedPlaced = currentSheet.placedItems + placedItem
                        val updatedFree = splitFreeRect(currentSheet.freeSpaces, rect, finalW, finalH, kerf)

                        val usedArea = updatedPlaced.sumOf { it.width * it.height }
                        val totalArea = currentSheet.totalArea
                        val wasteArea = totalArea - usedArea
                        val efficiency = (usedArea / totalArea) * 100.0

                        currentSheet = currentSheet.copy(
                            placedItems = updatedPlaced,
                            freeSpaces = updatedFree,
                            usedArea = usedArea,
                            wasteArea = wasteArea,
                            efficiencyPercentage = efficiency
                        )
                    } else {
                        // Failed to place even on empty new sheet
                        unplaced.add(item)
                    }
                }
            }
        }

        // Add the last active sheet if it has contents
        if (currentSheet.placedItems.isNotEmpty()) {
            sheets.add(currentSheet)
        }

        val totalSheets = sheets.size
        val overallEfficiency = if (totalSheets > 0) {
            sheets.sumOf { it.efficiencyPercentage } / totalSheets
        } else {
            0.0
        }

        // Group unplaced back into unique items with total quantities
        val groupedUnplaced = mutableListOf<CutItem>()
        unplaced.forEach { flatItem ->
            val cleanId = flatItem.id.substringBeforeLast("_")
            val existing = groupedUnplaced.find { it.id == cleanId }
            if (existing != null) {
                groupedUnplaced[groupedUnplaced.indexOf(existing)] = existing.copy(quantity = existing.quantity + 1)
            } else {
                val originalItem = items.find { it.id == cleanId }
                if (originalItem != null) {
                    groupedUnplaced.add(originalItem.copy(quantity = 1))
                }
            }
        }

        return OptimizerResult(
            sheets = sheets,
            unplacedItems = groupedUnplaced,
            totalSheetsUsed = totalSheets,
            overallEfficiency = overallEfficiency
        )
    }

    private fun findBestPlacement(
        freeSpaces: List<FreeRect>,
        itemW: Double,
        itemH: Double,
        allowRotation: Boolean
    ): Pair<FreeRect, Boolean>? {
        var bestRect: FreeRect? = null
        var bestRotated = false
        var minAreaFit = Double.MAX_VALUE

        for (rect in freeSpaces) {
            val fitsNormal = itemW <= rect.width && itemH <= rect.height
            val fitsRotated = allowRotation && itemH <= rect.width && itemW <= rect.height

            if (fitsNormal) {
                val areaDiff = (rect.width * rect.height) - (itemW * itemH)
                if (areaDiff < minAreaFit) {
                    minAreaFit = areaDiff
                    bestRect = rect
                    bestRotated = false
                }
            }
            if (fitsRotated) {
                val areaDiff = (rect.width * rect.height) - (itemW * itemH)
                if (areaDiff < minAreaFit) {
                    minAreaFit = areaDiff
                    bestRect = rect
                    bestRotated = true
                }
            }
        }

        return if (bestRect != null) Pair(bestRect, bestRotated) else null
    }

    private fun splitFreeRect(
        freeSpaces: List<FreeRect>,
        usedRect: FreeRect,
        placedW: Double,
        placedH: Double,
        kerf: Double
    ): List<FreeRect> {
        val newList = freeSpaces.toMutableList()
        newList.remove(usedRect)

        // Split along the shorter side (guillotine cut)
        val splitHorizontally = (usedRect.width - placedW) < (usedRect.height - placedH)

        if (splitHorizontally) {
            // Horizontal split:
            // Sub-rect 1 (right of placed item): width is (usedRect.width - placedW - kerf)
            val rightW = usedRect.width - placedW - kerf
            if (rightW > 0.1) {
                newList.add(FreeRect(
                    x = usedRect.x + placedW + kerf,
                    y = usedRect.y,
                    width = rightW,
                    height = placedH
                ))
            }
            // Sub-rect 2 (below placed item and right part): height is (usedRect.height - placedH - kerf)
            val bottomH = usedRect.height - placedH - kerf
            if (bottomH > 0.1) {
                newList.add(FreeRect(
                    x = usedRect.x,
                    y = usedRect.y + placedH + kerf,
                    width = usedRect.width,
                    height = bottomH
                ))
            }
        } else {
            // Vertical split:
            // Sub-rect 1 (right of placed item): width is (usedRect.width - placedW - kerf) spanning full height
            val rightW = usedRect.width - placedW - kerf
            if (rightW > 0.1) {
                newList.add(FreeRect(
                    x = usedRect.x + placedW + kerf,
                    y = usedRect.y,
                    width = rightW,
                    height = usedRect.height
                ))
            }
            // Sub-rect 2 (below placed item): height is (usedRect.height - placedH - kerf) and width of placed item
            val bottomH = usedRect.height - placedH - kerf
            if (bottomH > 0.1) {
                newList.add(FreeRect(
                    x = usedRect.x,
                    y = usedRect.y + placedH + kerf,
                    width = placedW,
                    height = bottomH
                ))
            }
        }

        return newList
    }
}
