package com.example.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Locale

enum class AppCurrency(val symbol: String, val displayName: String) {
    USD("$", "دولار أمريكي ($)"),
    SYP("ل.س", "ليرة سورية (ل.س)"),
    SAR("ر.س", "ريال سعودي (ر.س)")
}

enum class AppScreen {
    Dashboard,      // List of projects & overall stats
    ProjectDetails, // Measurements, pricing, invoices, and payments
    Optimizer,      // Board cutting optimizer (Cutting List Optimizer)
    QuickPricing,   // Instant stand-alone materials pricing calculator
}

data class QuickPricingItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String,
    val unitCost: Double,
    val quantity: Double,
    val unitType: String = "لوح"
)

class CarpenterViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CarpenterRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = CarpenterRepository(database.carpenterDao())
    }

    // Currency configuration
    var selectedCurrency by mutableStateOf(AppCurrency.USD)
    var usdToSypRate by mutableStateOf(14500.0) // 1 USD = 14,500 SYP
    var usdToSarRate by mutableStateOf(3.75)   // 1 USD = 3.75 SAR

    fun formatCurrency(valueInBase: Double): String {
        val convertedValue = when (selectedCurrency) {
            AppCurrency.USD -> valueInBase
            AppCurrency.SYP -> valueInBase * usdToSypRate
            AppCurrency.SAR -> valueInBase * usdToSarRate
        }
        val symbol = selectedCurrency.symbol
        return if (selectedCurrency == AppCurrency.SYP) {
            String.format(Locale.US, "%,.0f %s", convertedValue, symbol)
        } else {
            String.format(Locale.US, "%,.2f %s", convertedValue, symbol)
        }
    }

    fun toBaseCurrency(valueInCurrent: Double): Double {
        return when (selectedCurrency) {
            AppCurrency.USD -> valueInCurrent
            AppCurrency.SYP -> if (usdToSypRate > 0) valueInCurrent / usdToSypRate else valueInCurrent
            AppCurrency.SAR -> if (usdToSarRate > 0) valueInCurrent / usdToSarRate else valueInCurrent
        }
    }

    // Navigation State
    var currentScreen by mutableStateOf(AppScreen.Dashboard)
    var selectedProjectId by mutableStateOf<Int?>(null)

    // Projects Flow
    val projects: StateFlow<List<Project>> = repository.allProjects
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Current Project Details Flows
    private val _currentProject = MutableStateFlow<Project?>(null)
    val currentProject: StateFlow<Project?> = _currentProject.asStateFlow()

    private val _currentMeasurements = MutableStateFlow<List<Measurement>>(emptyList())
    val currentMeasurements: StateFlow<List<Measurement>> = _currentMeasurements.asStateFlow()

    private val _currentMaterials = MutableStateFlow<List<MaterialCost>>(emptyList())
    val currentMaterials: StateFlow<List<MaterialCost>> = _currentMaterials.asStateFlow()

    private val _currentPayments = MutableStateFlow<List<Payment>>(emptyList())
    val currentPayments: StateFlow<List<Payment>> = _currentPayments.asStateFlow()

    // Cutting Optimizer UI Inputs
    var sheetWidthInput by mutableStateOf("122.0")
    var sheetHeightInput by mutableStateOf("244.0")
    var sawKerfInput by mutableStateOf("0.3")
    var allowRotationInput by mutableStateOf(true)

    // List of items to optimize
    var optimizerItems by mutableStateOf<List<CutItem>>(
        listOf(
            CutItem("1", "جوانب مطبخ سفلي", 60.0, 90.0, 4, "#3F51B5"),
            CutItem("2", "أبواب دولاب علوي", 40.0, 70.0, 6, "#FFC107"),
            CutItem("3", "رفوف داخلية", 55.0, 55.0, 8, "#4CAF50"),
            CutItem("4", "سطح مكتب MDF", 80.0, 120.0, 2, "#E91E63")
        )
    )

    var optimizerResult by mutableStateOf<OptimizerResult?>(null)

    // Quick Pricing State
    var quickPricingItems by mutableStateOf<List<QuickPricingItem>>(emptyList())
    var quickPricingLaborCost by mutableStateOf("1500")
    var quickPricingProfitMargin by mutableStateOf("25") // percentage

    init {
        // Observe selected project ID to load its sub-data
        viewModelScope.launch {
            snapshotFlow { selectedProjectId }.collectLatest { id ->
                if (id != null) {
                    // Collect project object
                    launch {
                        repository.getProjectById(id).collect { proj ->
                            _currentProject.value = proj
                        }
                    }
                    // Collect measurements
                    launch {
                        repository.getMeasurementsForProject(id).collect { list ->
                            _currentMeasurements.value = list
                        }
                    }
                    // Collect materials
                    launch {
                        repository.getMaterialCostsForProject(id).collect { list ->
                            _currentMaterials.value = list
                        }
                    }
                    // Collect payments
                    launch {
                        repository.getPaymentsForProject(id).collect { list ->
                            _currentPayments.value = list
                        }
                    }
                } else {
                    _currentProject.value = null
                    _currentMeasurements.value = emptyList()
                    _currentMaterials.value = emptyList()
                    _currentPayments.value = emptyList()
                }
            }
        }

        // Trigger initial run of optimizer
        runOptimization()
    }

    // --- Navigation Functions ---
    fun navigateTo(screen: AppScreen, projectId: Int? = null) {
        selectedProjectId = projectId
        currentScreen = screen
    }

    fun navigateBack() {
        if (currentScreen == AppScreen.ProjectDetails) {
            currentScreen = AppScreen.Dashboard
            selectedProjectId = null
        } else if (currentScreen == AppScreen.Optimizer || currentScreen == AppScreen.QuickPricing) {
            currentScreen = AppScreen.Dashboard
        }
    }

    // --- Project Operations ---
    fun createProject(projectName: String, clientName: String, clientPhone: String, deliveryDate: Long, notes: String) {
        viewModelScope.launch {
            val newProj = Project(
                projectName = projectName,
                clientName = clientName,
                clientPhone = clientPhone,
                deliveryDate = deliveryDate,
                notes = notes
            )
            val generatedId = repository.insertProject(newProj)
            navigateTo(AppScreen.ProjectDetails, generatedId)
        }
    }

    fun updateProjectDetails(project: Project) {
        viewModelScope.launch {
            repository.updateProject(project)
        }
    }

    fun deleteProject(projectId: Int) {
        viewModelScope.launch {
            repository.deleteProjectById(projectId)
            if (selectedProjectId == projectId) {
                navigateBack()
            }
        }
    }

    fun toggleProjectCompletion(projectId: Int, isCompleted: Boolean) {
        viewModelScope.launch {
            projects.value.find { it.id == projectId }?.let { proj ->
                repository.updateProject(proj.copy(isCompleted = isCompleted))
            }
        }
    }

    // --- Measurement Operations ---
    fun addMeasurement(itemName: String, height: Double, width: Double, depth: Double, notes: String) {
        val projId = selectedProjectId ?: return
        viewModelScope.launch {
            val measurement = Measurement(
                projectId = projId,
                itemName = itemName,
                height = height,
                width = width,
                depth = depth,
                notes = notes
            )
            repository.insertMeasurement(measurement)
        }
    }

    fun deleteMeasurement(measurementId: Int) {
        viewModelScope.launch {
            repository.deleteMeasurementById(measurementId)
        }
    }

    // --- Material Cost & Price Operations ---
    fun addMaterialCost(materialName: String, unitType: String, unitCost: Double, quantity: Double) {
        val projId = selectedProjectId ?: return
        viewModelScope.launch {
            val material = MaterialCost(
                projectId = projId,
                materialName = materialName,
                unitType = unitType,
                unitCost = toBaseCurrency(unitCost),
                quantity = quantity
            )
            repository.insertMaterialCost(material)
            recalculateProjectTotals(projId)
        }
    }

    fun deleteMaterialCost(materialCostId: Int) {
        val projId = selectedProjectId ?: return
        viewModelScope.launch {
            repository.deleteMaterialCostById(materialCostId)
            recalculateProjectTotals(projId)
        }
    }

    private suspend fun recalculateProjectTotals(projectId: Int) {
        // Collect current list of materials and payments to compute totals
        val materials = repository.getMaterialCostsForProject(projectId).first()
        val payments = repository.getPaymentsForProject(projectId).first()
        val currentProj = repository.getProjectById(projectId).first() ?: return

        val totalCost = materials.sumOf { it.unitCost * it.quantity }
        val depositPaid = payments.sumOf { it.amount }

        // We can base the final price on: materials total cost + optional markup or labor cost
        // Let's assume finalPrice is totalCost * 1.3 (30% markup) if finalPrice was 0, or keep user updated pricing
        val laborCost = 0.0 // can be customized or simple margin
        val finalPrice = if (currentProj.finalPrice == 0.0) totalCost * 1.35 else currentProj.finalPrice

        repository.updateProject(
            currentProj.copy(
                totalCost = totalCost,
                finalPrice = finalPrice,
                depositPaid = depositPaid
            )
        )
    }

    fun updateProjectPricing(projectId: Int, finalPrice: Double, notes: String) {
        viewModelScope.launch {
            val currentProj = repository.getProjectById(projectId).first() ?: return@launch
            repository.updateProject(
                currentProj.copy(
                    finalPrice = toBaseCurrency(finalPrice),
                    notes = if (notes.isNotEmpty()) notes else currentProj.notes
                )
            )
        }
    }

    // --- Payment Operations ---
    fun addPayment(amount: Double, notes: String) {
        val projId = selectedProjectId ?: return
        viewModelScope.launch {
            val payment = Payment(
                projectId = projId,
                amount = toBaseCurrency(amount),
                notes = notes
            )
            repository.insertPayment(payment)
            recalculateProjectTotals(projId)
        }
    }

    fun deletePayment(paymentId: Int) {
        val projId = selectedProjectId ?: return
        viewModelScope.launch {
            repository.deletePaymentById(paymentId)
            recalculateProjectTotals(projId)
        }
    }

    // --- Cutting Optimizer Control ---
    fun updateSheetDimensions(w: String, h: String, kerf: String, rotation: Boolean) {
        sheetWidthInput = w
        sheetHeightInput = h
        sawKerfInput = kerf
        allowRotationInput = rotation
        runOptimization()
    }

    fun addOptimizerItem(name: String, width: Double, height: Double, qty: Int, colorHex: String) {
        val newItem = CutItem(
            id = java.util.UUID.randomUUID().toString(),
            name = name,
            width = width,
            height = height,
            quantity = qty,
            colorHex = colorHex
        )
        optimizerItems = optimizerItems + newItem
        runOptimization()
    }

    fun deleteOptimizerItem(id: String) {
        optimizerItems = optimizerItems.filter { it.id != id }
        runOptimization()
    }

    fun runOptimization() {
        val w = sheetWidthInput.toDoubleOrNull() ?: 122.0
        val h = sheetHeightInput.toDoubleOrNull() ?: 244.0
        val kerf = sawKerfInput.toDoubleOrNull() ?: 0.3
        val rotation = allowRotationInput

        optimizerResult = CuttingListOptimizer.optimize(
            sheetWidth = w,
            sheetHeight = h,
            items = optimizerItems,
            kerf = kerf,
            allowRotation = rotation
        )
    }

    fun importMeasurementsToOptimizer() {
        val currentMeasures = _currentMeasurements.value
        if (currentMeasures.isEmpty()) return

        // Map measurements to CutItems
        val colors = listOf("#4CAF50", "#FFC107", "#2196F3", "#9C27B0", "#E91E63", "#00BCD4", "#FF5722")
        var colIdx = 0

        val newItems = currentMeasures.map { m ->
            val color = colors[colIdx % colors.size]
            colIdx++
            CutItem(
                id = java.util.UUID.randomUUID().toString(),
                name = m.itemName,
                width = m.width,
                height = m.height,
                quantity = 1, // default quantity 1 for measurement, user can adjust
                colorHex = color
            )
        }

        optimizerItems = optimizerItems + newItems
        currentScreen = AppScreen.Optimizer
        runOptimization()
    }

    // --- Quick Pricing stand-alone ---
    fun addQuickPricingItem(name: String, unitCost: Double, qty: Double, unitType: String) {
        quickPricingItems = quickPricingItems + QuickPricingItem(
            name = name,
            unitCost = toBaseCurrency(unitCost),
            quantity = qty,
            unitType = unitType
        )
    }

    fun removeQuickPricingItem(id: String) {
        quickPricingItems = quickPricingItems.filter { it.id != id }
    }

    fun clearQuickPricing() {
        quickPricingItems = emptyList()
        quickPricingLaborCost = "100" // default base is 100 USD (instead of 1500)
        quickPricingProfitMargin = "25"
    }

    fun getQuickPricingResult(): QuickPricingResult {
        val rawMaterialsCost = quickPricingItems.sumOf { it.unitCost * it.quantity }
        val laborInActive = quickPricingLaborCost.toDoubleOrNull() ?: 0.0
        val labor = toBaseCurrency(laborInActive)
        val margin = quickPricingProfitMargin.toDoubleOrNull() ?: 0.0

        val subTotal = rawMaterialsCost + labor
        val marginValue = subTotal * (margin / 100.0)
        val finalCustomerPrice = subTotal + marginValue

        return QuickPricingResult(
            materialsTotal = rawMaterialsCost,
            laborCost = labor,
            profitMarginPercentage = margin,
            profitMarginValue = marginValue,
            finalPrice = finalCustomerPrice
        )
    }
}

data class QuickPricingResult(
    val materialsTotal: Double,
    val laborCost: Double,
    val profitMarginPercentage: Double,
    val profitMarginValue: Double,
    val finalPrice: Double
)

class CarpenterViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CarpenterViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return CarpenterViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
