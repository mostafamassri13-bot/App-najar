package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Professional Polish Theme Colors
val PolishPrimary = Color(0xFF0061A4)       // Primary brand blue
val PolishSecondary = Color(0xFF6D7177)     // Active project caption/gray text
val PolishAccent = Color(0xFFE28413)        // Highlight amber/orange accent
val PolishBackground = Color(0xFFF7F9FC)    // Soft clean gray-blue background
val PolishSurface = Color(0xFFFFFFFF)       // Pure white cards/containers
val PolishTextDark = Color(0xFF1A1C1E)      // Charcoal dark text
val PolishBorder = Color(0xFFDDE2E9)        // Light gray borders

// Wood drafting colors from design spec
val WoodBase = Color(0xFFF1E9DB)            // Wood board background
val WoodBorder = Color(0xFFD2B48C)          // Wood board border
val WoodItemFill = Color(0x4D8B5E34)        // Placed items transparent brown (30% alpha)
val WoodItemBorder = Color(0x808B5E34)      // Placed items border brown (50% alpha)

// Dark Theme Professional Polish
val PolishPrimaryDark = Color(0xFF9ECAFF)   // Light-blue for dark mode primary
val PolishBackgroundDark = Color(0xFF121316) // Deep navy-slate dark background
val PolishSurfaceDark = Color(0xFF1A1C1E)    // Dark card background
val PolishTextLight = Color(0xFFE2E2E6)     // Soft white dark text
val PolishBorderDark = Color(0xFF43474E)     // Dark borders

